#!D:\Program Files\Programming\Django Project\Supermarket Management System By MTH\sms-mth-venv\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
